package com.geektrust.backend.commands;

public enum Command {
    BALANCE,
    CHECK_IN,
    PRINT_SUMMARY
}
