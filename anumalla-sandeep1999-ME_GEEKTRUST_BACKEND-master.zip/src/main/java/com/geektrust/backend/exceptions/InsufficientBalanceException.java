package com.geektrust.backend.exceptions;

public class InsufficientBalanceException extends Exception{
    public InsufficientBalanceException() {
        super();
    }
    public InsufficientBalanceException(String message) {
        super(message);
    }
}
