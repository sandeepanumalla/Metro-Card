package com.geektrust.backend.entities;

public class BaseEntity {
    String id;
    public String getId() {
        return id;
    }
    
}
