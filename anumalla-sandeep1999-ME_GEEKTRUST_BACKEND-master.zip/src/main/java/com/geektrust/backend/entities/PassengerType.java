package com.geektrust.backend.entities;

public enum PassengerType {
    ADULT,
    SENIOR_CITIZEN,
    KID
}
